const config = {
    database:'weixin',
    username:'root',
    password:'123456qq',
    host:'localhost',
    secret:'875871ce35cbaea41c59e3e68a25b3a7',
    wxid:'wx4f6a5800a8abe179'
}
module.exports = config;